/* global React, window, module */

module.exports.preview = React.createClass({
  render: function() {
    return React.DOM.div();
  }
});
